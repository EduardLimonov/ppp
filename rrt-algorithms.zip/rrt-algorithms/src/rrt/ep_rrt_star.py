from src.rrt.rrt_connect import *
from src.rrt.rrt_star import *
from src.search_space.zone import Zone
import logging


class EPRRTStar(RRTStar):
    def __init__(self, X, Q, x_init, x_goal, max_samples, r, prc=0.01, rewire_count=None):
        super().__init__(X, Q, x_init, x_goal, max_samples, r, prc, rewire_count)
        self.rrt_connect = RRTConnect(X, np.array([2]), x_init, x_goal, max_samples, r, prc,)

    @staticmethod
    def __calc_path_len(path: list[tuple]):
        path = [np.array(point) for point in path]
        return np.sum([np.linalg.norm(path[i] - path[i + 1]) for i in range(len(path) - 1)])

    def ep_rrt_star(self, optimize: bool =True, epsilon: int =8):
        default_path = self.rrt_connect.rrt_connect()

        for i in range(len(default_path)):
            self.add_vertex(0, default_path[i])
            if i != 0:
                self.add_edge(0, default_path[i], default_path[i - 1])
        
        best_path = default_path
        while True:
            for q in self.Q:  # iterate over different edge lengths
                for i in range(q[1]):  # iterate over number of edges of given length to add
                    D = np.max(self.X.dimension_lengths) / epsilon
                    x_new, x_nearest = self.new_and_near(0, q, zone=Zone(best_path, D))
                    if x_new is None:
                        continue

                    # get nearby vertices and cost-to-come
                    L_near = self.get_nearby_vertices(0, self.x_init, x_new)

                    # check nearby vertices for total cost and connect shortest valid edge
                    self.connect_shortest_valid(0, x_new, L_near)

                    if x_new in self.trees[0].E:
                        # rewire tree
                        self.rewire(0, x_new, L_near)

                    solution = self.check_solution()
                    if solution[0] and (not optimize or self.samples_taken >= self.max_samples):
                        return solution[1]

                    best_path = self.reconstruct_path(0, self.x_init, self.x_goal)
                    logging.info(f"{self.samples_taken} {self.__calc_path_len(best_path)}")

    def rrt_star(self, optimize: bool = True):
        """
        Based on algorithm found in: Incremental Sampling-based Algorithms for Optimal Motion Planning
        http://roboticsproceedings.org/rss06/p34.pdf
        :return: set of Vertices; Edges in form: vertex: [neighbor_1, neighbor_2, ...]
        """
        self.add_vertex(0, self.x_init)
        self.add_edge(0, self.x_init, None)

        while True:
            for q in self.Q:  # iterate over different edge lengths
                for i in range(q[1]):  # iterate over number of edges of given length to add
                    x_new, x_nearest = self.new_and_near(0, q)
                    if x_new is None:
                        continue

                    # get nearby vertices and cost-to-come
                    L_near = self.get_nearby_vertices(0, self.x_init, x_new)

                    # check nearby vertices for total cost and connect shortest valid edge
                    self.connect_shortest_valid(0, x_new, L_near)

                    if x_new in self.trees[0].E:
                        # rewire tree
                        self.rewire(0, x_new, L_near)

                    solution = self.check_solution()
                    if solution[0] and (not optimize or self.samples_taken >= self.max_samples):
                        return solution[1]

                    if solution[0]:
                        best_path = self.reconstruct_path(0, self.x_init, self.x_goal)
                        logging.info(f"{self.samples_taken} {self.__calc_path_len(best_path)}")

