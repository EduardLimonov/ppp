import numpy as np


class Zone:
    def __init__(self, path: list[tuple], D: float):
        self.path = path = [np.array(point) for point in path]
        self.lens = [np.linalg.norm(path[i] - path[i + 1]) for i in range(len(path) - 1)]
        self.path_len = np.sum(self.lens)
        self.D = D

    @staticmethod
    def __angle(v1, v2):
        cos = max(min(np.sum(v1 * v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)), 1.), -1.)
        return np.arccos(cos)

    def random(self) -> np.ndarray:
        l = np.random.uniform(size=1)[0] * self.path_len

        slen = 0
        for i in range(len(self.lens)):
            if slen + self.lens[i] >= l:
                break
            slen += self.lens[i]

        delta = l - slen
        base = self.path[i] + (self.path[i + 1] - self.path[i]) * delta / self.lens[i]

        if i > 0:
            theta = self.__angle(self.path[i - 1] - self.path[i], self.path[i + 1] - self.path[i]) / 2
        else:
            theta = 0

        angle = 0  # np.random.uniform(-1, 1, size=1)[0] * theta
        random_space = np.random.uniform(-self.D, self.D, size=1)[0]

        base_unrotated = base + random_space * (self.path[i + 1] - self.path[i])  # * max(np.tan(angle), 1)
        x, y = base_unrotated - base
        if x == 0:
            x = 1e-2
        vector_rotation = np.array([-y / x, 1.])
        vector_rotation /= np.linalg.norm(vector_rotation) * random_space
        rotated = base + vector_rotation

        return rotated
