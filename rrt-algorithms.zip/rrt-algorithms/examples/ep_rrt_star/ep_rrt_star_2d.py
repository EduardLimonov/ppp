import numpy as np

from src.rrt.ep_rrt_star import EPRRTStar
from src.search_space.search_space import SearchSpace
from src.utilities.obstacle_generation import generate_random_obstacles
from src.utilities.plotting import Plot
import logging


logging.basicConfig(level=logging.INFO, filename="py_log.log", filemode="w")

X_dimensions = np.array([(0, 100), (0, 100)])  # dimensions of Search Space
x_init = (0, 0)  # starting location
x_goal = (100, 100)  # goal location

Q = np.array([(8, 4)])  # length of tree edges
r = 1  # length of smallest edge to check for intersection with obstacles
max_samples = 1000  # max number of samples to take before timing out
rewire_count = 32  # optional, number of nearby branches to rewire
prc = 0.1  # probability of checking for a connection to goal

# create Search Space
X = SearchSpace(X_dimensions)
n = 50
Obstacles = generate_random_obstacles(X, x_init, x_goal, n)


def make_pipeline(rtree: EPRRTStar, path, name):
    plot = Plot(name)
    plot.plot_tree(X, rtree.trees)
    if path is not None:
        plot.plot_path(X, path)
    plot.plot_obstacles(X, Obstacles)
    plot.plot_start(X, x_init)
    plot.plot_goal(X, x_goal)
    plot.draw(auto_open=True)


# create rrt_search
rrt = EPRRTStar(X, Q, x_init, x_goal, max_samples, r, prc, rewire_count)
make_pipeline(rrt, rrt.rrt_star(), 'rrt_star')

logging.info('split')
rrt = EPRRTStar(X, Q, x_init, x_goal, max_samples, r, prc, rewire_count)
make_pipeline(rrt, rrt.ep_rrt_star(), 'ep_rrt_star')

